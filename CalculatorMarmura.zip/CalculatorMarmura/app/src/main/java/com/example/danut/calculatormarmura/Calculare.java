package com.example.danut.calculatormarmura;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

import static java.lang.Double.parseDouble;
import static java.lang.Double.valueOf;

public class Calculare extends AppCompatActivity {

    private EditText lungime, latime, lungime1, lungime2, latime1, latime2, bucati;
    private CheckBox checkBoxLungime1, checkBoxLungime2, checkBoxLatime1, checkBoxLatime2;
    private Button buttonTotal;
    private TextView textViewSuprafata, textViewFaltuire;
    String lat_ime, lung_ime, buc_ati, lung_ime1, lung_ime2, lat_ime1, lat_ime2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculare);

        bucati = (EditText)findViewById(R.id.etBucati);
        textViewSuprafata = (TextView)findViewById(R.id.tvTotaSuprafata);
        textViewFaltuire = (TextView)findViewById(R.id.tvTotaFaltuire);

        lungime = (EditText)findViewById(R.id.etLungime);
        lungime1 = (EditText)findViewById(R.id.etLungime1);
        lungime2 = (EditText)findViewById(R.id.etLungime2);

        checkBoxLungime1 = (CheckBox)findViewById(R.id.cbLungime1);
        checkBoxLungime1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBoxLungime1.isChecked()){
                    lung_ime = lungime.getText().toString();
                    if(lung_ime.isEmpty()){
                        alertDialogLungime();
                        checkBoxLungime1.setChecked(false);
                        lungime.requestFocus();
                    }
                    else {
                        lungime1.setText(lung_ime);
                    }
                }

                else {
                    lungime1.setText(String.valueOf(0));
                }
            }
        });

        checkBoxLungime2 = (CheckBox) findViewById(R.id.cbLungime2);
        checkBoxLungime2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lung_ime = lungime.getText().toString();
                if(checkBoxLungime2.isChecked()){
                    if((lung_ime).isEmpty()){
                        alertDialogLungime();
                        checkBoxLungime2.setChecked(false);
                        lungime.requestFocus();
                    }
                    else {
                        lungime2.setText(lung_ime);
                    }
                }

                else{
                    lungime2.setText(String.valueOf(0));
                }
            }
        });

        latime = (EditText)findViewById(R.id.etLatime);
        latime1 = (EditText)findViewById(R.id.etLatime1);
        latime2 = (EditText)findViewById(R.id.etLatime2);

        checkBoxLatime1 = (CheckBox)findViewById(R.id.cbLatime1);
        checkBoxLatime1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lat_ime = latime.getText().toString();
                if(checkBoxLatime1.isChecked()){
                    if(lat_ime.isEmpty()){
                        alertDialogLatime();
                        checkBoxLatime1.setChecked(false);
                        latime.requestFocus();
                    }
                    else {
                        latime1.setText(lat_ime);
                    }
                }

                else{
                    latime1.setText(String.valueOf(0));
                }
            }
        });

        checkBoxLatime2 = (CheckBox)findViewById(R.id.cbLatime2);
        checkBoxLatime2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lat_ime = latime.getText().toString();
                if(checkBoxLatime2.isChecked()){
                    if(lat_ime.isEmpty()){
                        alertDialogLatime();
                        checkBoxLatime2.setChecked(false);
                        latime.requestFocus();
                    }
                    else {
                        latime2.setText(lat_ime);
                    }
                }

                else{
                    latime2.setText(String.valueOf(0));
                }
            }
        });

        buttonTotal = (Button)findViewById(R.id.btnTotal);
        buttonTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lung_ime = lungime.getText().toString();
                lat_ime = latime.getText().toString();
                buc_ati = bucati.getText().toString();
                lung_ime1 = lungime1.getText().toString();
                lung_ime2 = lungime2.getText().toString();
                lat_ime1 = latime1.getText().toString();
                lat_ime2 = latime2.getText().toString();

                if(lung_ime.isEmpty()){
                    alertDialogLungime();
                    lungime.requestFocus();
                }

                else if(lat_ime.isEmpty()){
                    alertDialogLatime();
                    latime.requestFocus();
                }

                else if(buc_ati.isEmpty()){
                    alertDialogBucati();
                    bucati.requestFocus();
                }

                else if(lung_ime1.isEmpty()){
                    Toast.makeText(Calculare.this, "Adauga Lungime 1", Toast.LENGTH_SHORT).show();
                    lungime1.requestFocus();
                }

                else if(lung_ime2.isEmpty()){
                    Toast.makeText(Calculare.this, "Adaugă Lungime 2", Toast.LENGTH_SHORT).show();
                    lungime2.requestFocus();
                }

                else if(lat_ime1.isEmpty()){
                    Toast.makeText(Calculare.this, "Adaugă Lăţime 1", Toast.LENGTH_SHORT).show();
                    latime1.requestFocus();
                }

                else if(lat_ime2.isEmpty()){
                    Toast.makeText(Calculare.this, "Adaugă Lăţime 2", Toast.LENGTH_SHORT).show();
                    latime2.requestFocus();
                }

                else {
                    double lung_ime = parseDouble(lungime.getText().toString());
                    double lat_ime = parseDouble(latime.getText().toString());
                    int buc_ati = Integer.parseInt(bucati.getText().toString());
                    double total_suprafata;
                    total_suprafata = (lung_ime*lat_ime*buc_ati);

                    total_suprafata = roundTwoDecimalsSuprafata(total_suprafata);
                    textViewSuprafata.setText(String.valueOf(total_suprafata+" m2"));

                    double lung_ime1 = parseDouble(lungime1.getText().toString());
                    double lung_ime2 = parseDouble(lungime2.getText().toString());

                    double lati_ime1 = parseDouble(latime1.getText().toString());
                    double lati_ime2 = parseDouble(latime2.getText().toString());

                    double total_faltuire;
                    total_faltuire = (lung_ime1+lung_ime2+lati_ime1+lati_ime2)*buc_ati;

                    total_faltuire = roundTwoDecimalsFaltuire(total_faltuire);
                    textViewFaltuire.setText(String.valueOf(total_faltuire+" m"));

                }
            }
        });
    }

    public double roundTwoDecimalsSuprafata(double total_suprafata){
        DecimalFormat twoDForm = new DecimalFormat("#.###");
        return valueOf(twoDForm.format(total_suprafata));
    }

    public double roundTwoDecimalsFaltuire(double total_faltuire){
        DecimalFormat twoDForm = new DecimalFormat("#.###");
        return valueOf(twoDForm.format(total_faltuire));
    }

    public void alertDialogLungime(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Adaugă valoare Lungime");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogLatime(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Adaugă valoare Lăţime");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void alertDialogBucati(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Adaugă Număr Bucăţi");
        alertDialogBuilder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
